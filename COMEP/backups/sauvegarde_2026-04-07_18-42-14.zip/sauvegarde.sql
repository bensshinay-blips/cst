-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: comep_gestion
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acces_bulletins`
--

DROP TABLE IF EXISTS `acces_bulletins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acces_bulletins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `eleve_id` int NOT NULL,
  `annee_scolaire` varchar(20) NOT NULL,
  `acces` enum('autorise','bloque') NOT NULL DEFAULT 'bloque',
  `motif_blocage` varchar(255) DEFAULT 'Frais scolaires impayés',
  `autorise_par` int DEFAULT NULL,
  `autorise_le` datetime DEFAULT NULL,
  `bloque_par` int DEFAULT NULL,
  `bloque_le` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_eleve_annee` (`eleve_id`,`annee_scolaire`),
  KEY `idx_acces` (`acces`),
  KEY `idx_eleve` (`eleve_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acces_bulletins`
--

LOCK TABLES `acces_bulletins` WRITE;
/*!40000 ALTER TABLE `acces_bulletins` DISABLE KEYS */;
INSERT INTO `acces_bulletins` VALUES (1,9,'2026-2027','bloque','Frais scolaires impayés',NULL,NULL,NULL,NULL,'2026-03-29 12:15:28','2026-03-29 12:15:28'),(2,10,'2026-2027','bloque','Frais scolaires impayés',NULL,NULL,NULL,NULL,'2026-03-29 12:15:28','2026-03-29 12:15:28'),(3,7,'2026-2027','bloque','Frais scolaires impayés',NULL,NULL,NULL,NULL,'2026-03-29 12:15:28','2026-03-29 12:15:28'),(4,8,'2026-2027','bloque','Frais scolaires impayés',NULL,NULL,NULL,NULL,'2026-03-29 12:15:28','2026-03-29 12:15:28'),(5,11,'2026-2027','bloque','Frais scolaires impayés',NULL,NULL,NULL,NULL,'2026-03-29 12:15:28','2026-03-29 12:15:28'),(6,12,'2026-2027','bloque','Frais scolaires impayés',NULL,NULL,NULL,NULL,'2026-03-29 12:15:28','2026-03-29 12:15:28'),(7,13,'2026-2027','bloque','Frais scolaires impayés',NULL,NULL,NULL,NULL,'2026-03-29 12:15:28','2026-03-29 12:15:28'),(8,13,'2024-2025','autorise','Frais scolaires impayés',6,'2026-04-03 11:00:54',NULL,NULL,'2026-03-29 12:42:03','2026-04-03 15:00:54'),(9,11,'2024-2025','bloque','Frais scolaires impayés',NULL,NULL,NULL,NULL,'2026-03-31 14:21:05','2026-03-31 14:21:05'),(10,12,'2024-2025','autorise','Frais scolaires impayés',6,'2026-03-31 10:21:11',NULL,NULL,'2026-03-31 14:21:05','2026-03-31 14:21:11'),(11,9,'2024-2025','autorise','Frais scolaires impayés',6,'2026-04-06 14:19:46',NULL,NULL,'2026-03-31 14:21:25','2026-04-06 18:19:46'),(12,7,'2024-2025','bloque','Frais scolaires impayés',NULL,NULL,NULL,NULL,'2026-03-31 14:21:34','2026-03-31 14:21:34'),(13,15,'2024-2025','bloque','Frais scolaires impayés',NULL,NULL,6,'2026-04-05 13:53:20','2026-04-04 22:42:35','2026-04-05 17:53:20'),(14,18,'2024-2025','bloque','Frais scolaires impayés',NULL,NULL,6,'2026-04-05 13:53:20','2026-04-04 22:42:35','2026-04-05 17:53:20'),(15,21,'2024-2025','bloque','Frais scolaires impayés',NULL,NULL,6,'2026-04-05 13:53:20','2026-04-04 22:42:35','2026-04-05 17:53:20'),(16,24,'2024-2025','bloque','Frais scolaires impayés',NULL,NULL,6,'2026-04-05 13:53:20','2026-04-04 22:42:35','2026-04-05 17:53:20');
/*!40000 ALTER TABLE `acces_bulletins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bulletins`
--

DROP TABLE IF EXISTS `bulletins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bulletins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `eleve_id` int NOT NULL,
  `controle_id` int NOT NULL,
  `notes_details` json DEFAULT NULL,
  `moyenne_periode` decimal(4,2) DEFAULT NULL,
  `appreciation` text,
  `annee_scolaire` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `eleve_id` (`eleve_id`),
  KEY `controle_id` (`controle_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bulletins`
--

LOCK TABLES `bulletins` WRITE;
/*!40000 ALTER TABLE `bulletins` DISABLE KEYS */;
/*!40000 ALTER TABLE `bulletins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classe_matieres`
--

DROP TABLE IF EXISTS `classe_matieres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `classe_matieres` (
  `id` int NOT NULL AUTO_INCREMENT,
  `classe_id` int NOT NULL,
  `matiere_id` int NOT NULL,
  `bareme` int NOT NULL DEFAULT '100',
  `annee_scolaire` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_classe_matiere_annee` (`classe_id`,`matiere_id`,`annee_scolaire`),
  KEY `idx_classe_annee` (`classe_id`,`annee_scolaire`)
) ENGINE=MyISAM AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classe_matieres`
--

LOCK TABLES `classe_matieres` WRITE;
/*!40000 ALTER TABLE `classe_matieres` DISABLE KEYS */;
INSERT INTO `classe_matieres` VALUES (4,9,16,100,'2024-2025','2026-03-27 22:22:55'),(3,9,14,200,'2024-2025','2026-03-27 22:22:42'),(5,9,28,200,'2024-2025','2026-03-27 22:23:16'),(6,9,26,100,'2024-2025','2026-03-27 22:23:38'),(7,9,20,200,'2024-2025','2026-03-27 22:23:49'),(8,9,18,200,'2024-2025','2026-03-27 22:24:05'),(9,10,14,200,'2024-2025','2026-03-27 22:25:29'),(10,10,16,100,'2024-2025','2026-03-27 22:25:39'),(11,10,28,200,'2024-2025','2026-03-27 22:25:52'),(12,10,26,200,'2024-2025','2026-03-27 22:26:10'),(13,10,18,200,'2024-2025','2026-03-27 22:26:24'),(14,10,20,200,'2024-2025','2026-03-27 22:26:34'),(15,11,14,200,'2024-2025','2026-03-27 22:27:10'),(16,9,29,200,'2024-2025','2026-03-27 22:27:49'),(17,10,29,200,'2024-2025','2026-03-27 22:28:03'),(18,11,16,100,'2024-2025','2026-03-27 22:28:45'),(19,11,18,200,'2024-2025','2026-03-27 22:30:27'),(20,11,29,200,'2024-2025','2026-03-27 22:30:44'),(21,11,26,200,'2024-2025','2026-03-27 22:30:56'),(22,11,28,200,'2024-2025','2026-03-27 22:31:09'),(23,11,20,200,'2024-2025','2026-03-27 22:31:30'),(24,8,14,200,'2024-2025','2026-03-27 22:31:53'),(25,8,16,100,'2024-2025','2026-03-27 22:32:05'),(26,8,18,200,'2024-2025','2026-03-27 22:32:15'),(27,8,15,300,'2024-2025','2026-03-27 22:32:22'),(28,8,29,200,'2024-2025','2026-03-27 22:32:31'),(29,8,22,100,'2024-2025','2026-03-27 22:32:39'),(30,8,28,200,'2024-2025','2026-03-27 22:32:47'),(31,8,17,200,'2024-2025','2026-03-27 22:32:56'),(32,8,26,100,'2024-2025','2026-03-27 22:33:04'),(33,8,23,100,'2024-2025','2026-03-27 22:33:10'),(34,8,20,200,'2024-2025','2026-03-27 22:33:20'),(35,8,27,100,'2024-2025','2026-03-27 22:33:27'),(36,8,25,200,'2024-2025','2026-03-27 22:33:40'),(37,9,16,100,'2026-2027','2026-03-27 22:40:39'),(38,9,14,200,'2026-2027','2026-03-27 22:40:39'),(39,9,28,200,'2026-2027','2026-03-27 22:40:39'),(40,9,26,100,'2026-2027','2026-03-27 22:40:39'),(41,9,20,200,'2026-2027','2026-03-27 22:40:39'),(42,9,18,200,'2026-2027','2026-03-27 22:40:39'),(43,10,14,200,'2026-2027','2026-03-27 22:40:39'),(44,10,16,100,'2026-2027','2026-03-27 22:40:39'),(45,10,28,200,'2026-2027','2026-03-27 22:40:39'),(46,10,26,200,'2026-2027','2026-03-27 22:40:39'),(47,10,18,200,'2026-2027','2026-03-27 22:40:39'),(48,10,20,200,'2026-2027','2026-03-27 22:40:39'),(49,11,14,200,'2026-2027','2026-03-27 22:40:39'),(50,9,29,200,'2026-2027','2026-03-27 22:40:39'),(51,10,29,200,'2026-2027','2026-03-27 22:40:39'),(52,11,16,100,'2026-2027','2026-03-27 22:40:39'),(53,11,18,200,'2026-2027','2026-03-27 22:40:39'),(54,11,29,200,'2026-2027','2026-03-27 22:40:39'),(55,11,26,200,'2026-2027','2026-03-27 22:40:39'),(56,11,28,200,'2026-2027','2026-03-27 22:40:39'),(57,11,20,200,'2026-2027','2026-03-27 22:40:39'),(58,8,14,200,'2026-2027','2026-03-27 22:40:39'),(59,8,16,100,'2026-2027','2026-03-27 22:40:39'),(60,8,18,200,'2026-2027','2026-03-27 22:40:39'),(61,8,15,300,'2026-2027','2026-03-27 22:40:39'),(62,8,29,200,'2026-2027','2026-03-27 22:40:39'),(63,8,22,100,'2026-2027','2026-03-27 22:40:39'),(64,8,28,200,'2026-2027','2026-03-27 22:40:39'),(65,8,17,200,'2026-2027','2026-03-27 22:40:39'),(66,8,26,100,'2026-2027','2026-03-27 22:40:39'),(67,8,23,100,'2026-2027','2026-03-27 22:40:39'),(68,8,20,200,'2026-2027','2026-03-27 22:40:39'),(69,8,27,100,'2026-2027','2026-03-27 22:40:39'),(70,8,25,200,'2026-2027','2026-03-27 22:40:39'),(71,14,24,200,'2024-2025','2026-03-29 00:03:27'),(72,14,19,200,'2024-2025','2026-03-29 00:03:41'),(73,14,26,100,'2024-2025','2026-03-29 00:03:52'),(74,14,14,200,'2024-2025','2026-03-29 00:05:25'),(75,14,16,100,'2024-2025','2026-03-29 00:06:15'),(76,14,18,200,'2024-2025','2026-03-29 00:06:25'),(77,14,17,200,'2024-2025','2026-03-29 00:06:33'),(78,14,15,300,'2024-2025','2026-03-29 00:06:40'),(79,14,20,200,'2024-2025','2026-03-29 00:06:48'),(80,14,25,100,'2024-2025','2026-03-29 00:07:01'),(81,14,29,200,'2024-2025','2026-03-29 00:07:08'),(82,9,25,100,'2024-2025','2026-04-01 01:15:06'),(83,14,30,100,'2024-2025','2026-04-06 19:35:51');
/*!40000 ALTER TABLE `classe_matieres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `classes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `niveau` varchar(20) NOT NULL,
  `capacite` int DEFAULT '40',
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_niveau` (`niveau`),
  KEY `idx_nom` (`nom`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes`
--

LOCK TABLES `classes` WRITE;
/*!40000 ALTER TABLE `classes` DISABLE KEYS */;
INSERT INTO `classes` VALUES (12,'Saint Augustin','NS2',40,'','2026-03-27 22:00:24','2026-03-31 00:43:39'),(13,'Emmanuel Kant','NS3',38,'','2026-03-27 22:00:53','2026-03-31 00:43:49'),(10,'Aristote','8eme',54,'','2026-03-27 21:58:39','2026-03-31 00:43:15'),(9,'Antoine Dupre','7eme',56,'','2026-03-27 21:57:57','2026-03-31 00:43:08'),(8,'Socrate','NS1',60,'','2026-03-27 12:42:06','2026-03-31 00:43:31'),(11,'Victor Hugo','9eme',76,'','2026-03-27 21:58:58','2026-03-31 00:43:22'),(14,'Platon','NS4',68,'','2026-03-27 22:01:40','2026-03-31 00:43:57');
/*!40000 ALTER TABLE `classes` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `before_delete_class` BEFORE DELETE ON `classes` FOR EACH ROW BEGIN
    DECLARE eleve_count INT;
    -- Sèlman verifye si gen elev epi pa gen fòs efase
    SELECT COUNT(*) INTO eleve_count FROM eleves WHERE classe_id = OLD.id;
    IF eleve_count > 0 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'ATANSYON: Klas sa gen elev. Pou efase l, ou dwe deplase elev yo anvan.';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `controles`
--

DROP TABLE IF EXISTS `controles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `controles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `numero` int NOT NULL,
  `periode` varchar(100) DEFAULT NULL,
  `date_debut` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  `annee_scolaire` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `controles`
--

LOCK TABLES `controles` WRITE;
/*!40000 ALTER TABLE `controles` DISABLE KEYS */;
INSERT INTO `controles` VALUES (1,'1er Trimestre',1,'Septanm - Oktòb','2024-09-01','2024-10-31','2024-2025','2026-03-26 16:45:36'),(2,'2ème Trimestre',2,'Janvye - Mas','2025-01-01','2025-03-31','2024-2025','2026-03-26 16:45:36'),(3,'3ème Trimestre',3,'Avril - Jen','2025-04-01','2025-06-30','2024-2025','2026-03-26 16:45:36'),(4,'1er Trimestre',1,'Septanm - Oktòb','2026-09-01','2026-10-31','2025-2026','2026-03-27 01:26:53'),(5,'2ème Trimestre',2,'Janvye - Mas','2027-01-01','2027-03-31','2025-2026','2026-03-27 01:26:53'),(6,'3ème Trimestre',3,'Avril - Jen','2027-04-01','2027-06-30','2025-2026','2026-03-27 01:26:53'),(7,'1er Trimestre',1,'Septanm - Oktòb','2026-09-01','2026-10-31','2026-2027','2026-03-27 22:40:39'),(8,'2ème Trimestre',2,'Janvye - Mas','2027-01-01','2027-03-31','2026-2027','2026-03-27 22:40:39'),(9,'3ème Trimestre',3,'Avril - Jen','2027-04-01','2027-06-30','2026-2027','2026-03-27 22:40:39');
/*!40000 ALTER TABLE `controles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eleves`
--

DROP TABLE IF EXISTS `eleves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eleves` (
  `id` int NOT NULL AUTO_INCREMENT,
  `matricule` varchar(50) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `sexe` enum('M','F') DEFAULT 'M',
  `date_naissance` date DEFAULT NULL,
  `lieu_naissance` varchar(100) DEFAULT NULL,
  `adresse` text,
  `telephone_parent` varchar(20) DEFAULT NULL,
  `classe_id` int DEFAULT NULL,
  `annee_scolaire` varchar(20) NOT NULL,
  `status` enum('actif','inactif','diplome') DEFAULT 'actif',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matricule` (`matricule`),
  KEY `idx_classe` (`classe_id`),
  KEY `idx_status` (`status`),
  KEY `idx_matricule` (`matricule`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eleves`
--

LOCK TABLES `eleves` WRITE;
/*!40000 ALTER TABLE `eleves` DISABLE KEYS */;
INSERT INTO `eleves` VALUES (9,'2026003','roobens','Jean','M','2010-09-12','Corail','Bas-Terrasment','509 43214332',9,'2026-2027','actif','2026-03-27 22:12:51','2026-03-27 22:40:39'),(10,'2026004','Louis','Vanessa','F','2009-02-09','Bizoton','Carrefour','50937891234',13,'2026-2027','actif','2026-03-27 22:15:04','2026-03-27 22:40:39'),(7,'2026001','Pierre','Jean','M','2008-03-04','Port-au-Prince','Delmas 33','50934567890',8,'2026-2027','actif','2026-03-27 22:07:57','2026-03-27 22:40:39'),(8,'2026002','Rodens','Estimable','M','2009-11-03','Port-Margot','Rue Jolius Pluviose','50933842285',13,'2026-2027','actif','2026-03-27 22:09:23','2026-03-27 22:40:39'),(11,'2026005','Joseph','Kevin','M','2011-11-04','Pétion-Ville','Pétion-Ville','50936124578',10,'2026-2027','actif','2026-03-27 22:16:06','2026-03-27 22:40:39'),(12,'2026006','Charles','Naomi','F','2012-12-08','Tabarre 27','Tabarre 27','50938965412',10,'2026-2027','actif','2026-03-27 22:18:03','2026-03-27 22:40:39'),(13,'2026007','François','Junior','M','2006-03-04','Croix-des-Bouquets','Croix-des-Bouquets','50937219845',14,'2026-2027','actif','2026-03-27 22:19:07','2026-03-27 22:40:39'),(14,'2025001','BAPTISTE','Willy','M','2010-09-10','Cap-Haïtien','Rue 14, Cap-Haïtien','38923456',10,'2025-2026','actif','2026-04-02 21:01:30','2026-04-02 21:01:30'),(15,'2025002','DORSAINT','Robenson','M','2011-11-28','Nord','Limonade, Nord','37345678',9,'2025-2026','actif','2026-04-02 21:01:30','2026-04-02 21:01:30'),(16,'2025003','ÉTIENNE','Patrick','M','2009-07-03','Cap-Haïtien','Avenue B, Cap-Haïtien','36567890',11,'2025-2026','actif','2026-04-02 21:01:30','2026-04-02 21:01:30'),(17,'2025004','DÉSIR','Samuel','M','2010-02-25','Nord','Plaine du Nord','38789012',10,'2025-2026','actif','2026-04-02 21:01:30','2026-04-02 21:01:30'),(18,'2025005','THOMAS','Claudette','F','2011-05-30','Port-Margot','Rue Église, Port-Margot','36890123',9,'2025-2026','actif','2026-04-02 21:01:30','2026-04-02 21:01:30'),(19,'2025006','ARISTIDE','Guerline','F','2009-12-08','Port-Margot','Grande Rue, Port-Margot','38012345',11,'2025-2026','actif','2026-04-02 21:01:30','2026-04-02 21:01:30'),(20,'2025007','LAFLEUR','Mirlande','F','2010-06-11','Port-Margot','Rue Commerce, Port-Margot','37234567',10,'2025-2026','actif','2026-04-02 21:01:30','2026-04-02 21:01:30'),(21,'2025008','CLERVIL','Widlove','M','2011-09-27','Cap-Haïtien','Rue 17, Cap-Haïtien','38345678',9,'2025-2026','actif','2026-04-02 21:01:30','2026-04-02 21:01:30'),(22,'2025009','MICHAUD','Frantz','M','2009-04-02','Nord','Milot, Nord','37567890',11,'2025-2026','actif','2026-04-02 21:01:30','2026-04-02 21:01:30'),(23,'2025010','DUCLOS','Djimy','M','2010-11-04','Cap-Haïtien','Carrefour Shada, Cap-Haïtien','36789012',10,'2025-2026','actif','2026-04-02 21:01:30','2026-04-02 21:01:30'),(24,'2025011','SAINT-LOUIS','Widline','F','2011-08-13','Port-Margot','Rue Centrale, Port-Margot','37890123',9,'2025-2026','actif','2026-04-02 21:01:30','2026-04-02 21:01:30'),(25,'2026008','Jean','Isaac','M','2009-03-23','Port-au-Prince','Caap haitien','33131807',14,'2024-2025','actif','2026-04-05 00:41:26','2026-04-05 00:41:26'),(26,'2026009','Asley','Jean','M','2000-12-09','Port-au-Prince','Cap haitien','33131807',14,'2024-2025','actif','2026-04-06 19:37:02','2026-04-06 19:37:02');
/*!40000 ALTER TABLE `eleves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `utilisateur_id` int DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `table_name` varchar(50) DEFAULT NULL,
  `record_id` int DEFAULT NULL,
  `details` text,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `utilisateur_id` (`utilisateur_id`)
) ENGINE=MyISAM AUTO_INCREMENT=466 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` VALUES (1,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-26 23:17:39'),(2,1,'SUPPRESSION CLASSE','classes',5,'Classe: 10èm','::1','2026-03-26 23:18:04'),(3,1,'AJOUT ÉLÈVE','eleves',4,'Estavieb Rodens - Mat: 2026001','::1','2026-03-26 23:22:11'),(4,1,'SUPPRESSION MATIERE','matieres',8,'Matière: Syonat','::1','2026-03-26 23:26:16'),(5,2,'CONNEXION','utilisateurs',2,'Connexion réussie','::1','2026-03-26 23:30:52'),(6,2,'DECONNEXION','utilisateurs',2,'Déconnexion','::1','2026-03-26 23:32:34'),(7,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-26 23:33:03'),(8,1,'MODIFICATION CLASSE','classes',2,'Classe: 7èm B','::1','2026-03-26 23:34:27'),(9,1,'AJOUT PROFESSEUR','utilisateurs',3,'Joseph Estime','::1','2026-03-26 23:36:04'),(10,1,'MODIFICATION PROFESSEUR','utilisateurs',3,'Joseph Estime','::1','2026-03-26 23:36:31'),(11,1,'SUPPRESSION CLASSE','classes',7,'Classe: NS4','::1','2026-03-26 23:38:47'),(12,1,'ASSIGNATION','professeur_classes',2,'Prof:3 Classe:6 Mat:5','::1','2026-03-26 23:43:41'),(13,1,'ASSIGNATION','professeur_classes',3,'Prof:3 Classe:6 Mat:11','::1','2026-03-26 23:44:06'),(14,1,'AJOUT MATIERE','matieres',13,'Algebre (MATHE)','::1','2026-03-26 23:49:11'),(15,1,'AJOUT PROFESSEUR','utilisateurs',4,'Emmanuel Estimable','::1','2026-03-27 00:36:48'),(16,1,'ASSIGNATION','professeur_classes',4,'Prof:4 Classe:4 Mat:3','::1','2026-03-27 00:37:32'),(17,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-27 00:41:14'),(18,1,'MODIFICATION PROFESSEUR','utilisateurs',4,'Emmanuel Estimable','::1','2026-03-27 00:41:33'),(19,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-27 00:42:00'),(20,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-27 00:42:57'),(21,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-27 00:43:28'),(22,4,'CONNEXION','utilisateurs',4,'Connexion réussie','::1','2026-03-27 00:43:56'),(23,4,'DECONNEXION','utilisateurs',4,'Déconnexion','::1','2026-03-27 00:47:57'),(24,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-27 00:48:40'),(25,1,'AJOUT ÉLÈVE','eleves',5,'Roseline Estiamble - Mat: 2026002','::1','2026-03-27 00:49:39'),(26,1,'AJOUT ÉLÈVE','eleves',6,'Rodens Estavien - Mat: 2026003','::1','2026-03-27 00:52:48'),(27,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-27 00:52:56'),(28,4,'CONNEXION','utilisateurs',4,'Connexion réussie','::1','2026-03-27 00:53:03'),(29,4,'DECONNEXION','utilisateurs',4,'Déconnexion','::1','2026-03-27 00:56:19'),(30,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-27 00:56:25'),(31,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-27 00:56:56'),(32,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-27 00:57:15'),(33,1,'NOUVELLE ANNÉE SCOLAIRE','systeme',NULL,'Passage de 2024-2025 vers 2025-2026 — 0 diplômés, 0 montés, 0 redoublants','::1','2026-03-27 01:26:53'),(34,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-27 01:27:31'),(35,4,'CONNEXION','utilisateurs',4,'Connexion réussie','::1','2026-03-27 01:27:36'),(36,4,'SAISIE NOTES','notes',NULL,'Classe:4 Mat:3 Ctrl:4 - 2 notes','::1','2026-03-27 01:28:13'),(37,4,'DECONNEXION','utilisateurs',4,'Déconnexion','::1','2026-03-27 01:28:27'),(38,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-27 01:28:32'),(39,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-27 01:29:19'),(40,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-27 01:45:36'),(41,1,'SUPPRESSION CLASSE','classes',3,'Classe: 8èm','::1','2026-03-27 01:50:13'),(42,1,'SUPPRESSION CLASSE','classes',2,'Classe: 7èm B','::1','2026-03-27 01:50:19'),(43,1,'SUPPRESSION ÉLÈVE','eleves',4,'Rodens Estavieb','::1','2026-03-27 01:50:47'),(44,1,'SUPPRESSION ÉLÈVE','eleves',1,'Marie Jean','::1','2026-03-27 01:50:50'),(45,1,'SUPPRESSION ÉLÈVE','eleves',3,'Anne Joseph','::1','2026-03-27 01:50:53'),(46,1,'SUPPRESSION ÉLÈVE','eleves',2,'Paul Pierre','::1','2026-03-27 01:50:56'),(47,1,'SUPPRESSION ÉLÈVE','eleves',6,'Estavien Rodens','::1','2026-03-27 01:50:59'),(48,1,'SUPPRESSION ÉLÈVE','eleves',5,'Estiamble Roseline','::1','2026-03-27 01:51:03'),(49,1,'SUPPRESSION MATIERE','matieres',13,'Matière: Algebre','::1','2026-03-27 01:51:15'),(50,1,'SUPPRESSION MATIERE','matieres',3,'Matière: Anglè','::1','2026-03-27 01:51:19'),(51,1,'SUPPRESSION MATIERE','matieres',6,'Matière: Chimi','::1','2026-03-27 01:51:22'),(52,1,'SUPPRESSION MATIERE','matieres',10,'Matière: Edikasyon Fizik','::1','2026-03-27 01:51:25'),(53,1,'SUPPRESSION MATIERE','matieres',4,'Matière: Espanyòl','::1','2026-03-27 01:51:28'),(54,1,'SUPPRESSION MATIERE','matieres',11,'Matière: Filozofi','::1','2026-03-27 01:51:32'),(55,1,'SUPPRESSION MATIERE','matieres',7,'Matière: Fizik','::1','2026-03-27 01:51:35'),(56,1,'SUPPRESSION MATIERE','matieres',2,'Matière: Fransè','::1','2026-03-27 01:51:38'),(57,1,'SUPPRESSION MATIERE','matieres',9,'Matière: Istwa/Jeografi','::1','2026-03-27 01:51:41'),(58,1,'SUPPRESSION MATIERE','matieres',1,'Matière: Matematik','::1','2026-03-27 01:51:46'),(59,1,'SUPPRESSION MATIERE','matieres',5,'Matière: Mizik','::1','2026-03-27 01:51:49'),(60,1,'SUPPRESSION MATIERE','matieres',12,'Matière: Syans Ekonomik','::1','2026-03-27 01:51:53'),(61,1,'SUPPRESSION CLASSE','classes',1,'Classe: 7èm A','::1','2026-03-27 01:52:02'),(62,1,'SUPPRESSION CLASSE','classes',4,'Classe: 9èm','::1','2026-03-27 01:52:05'),(63,1,'SUPPRESSION CLASSE','classes',6,'Classe: NS3','::1','2026-03-27 01:52:09'),(64,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-27 12:30:00'),(65,1,'AJOUT CLASSE','classes',8,'Classe: Socrate','::1','2026-03-27 12:42:06'),(66,1,'AJOUT MATIERE','matieres',14,'Anglais (ANG)','::1','2026-03-27 12:46:49'),(67,1,'AJOUT MATIERE','matieres',15,'Chimie (CHI)','::1','2026-03-27 12:49:28'),(68,1,'AJOUT MATIERE','matieres',16,'Bible (BIB)','::1','2026-03-27 12:58:29'),(69,1,'AJOUT MATIERE','matieres',17,'Geologie (GEO)','::1','2026-03-27 12:59:15'),(70,1,'AJOUT MATIERE','matieres',18,'Biologie (BIO)','::1','2026-03-27 12:59:33'),(71,1,'AJOUT MATIERE','matieres',19,'Nombre Complexe (NC)','::1','2026-03-27 13:00:18'),(72,1,'AJOUT MATIERE','matieres',20,'Science Social (SCS)','::1','2026-03-27 21:53:14'),(73,1,'AJOUT MATIERE','matieres',21,'Science Experimental (SCE)','::1','2026-03-27 21:53:56'),(74,1,'AJOUT MATIERE','matieres',22,'Education Physique Sportive (EPS)','::1','2026-03-27 21:54:41'),(75,1,'AJOUT MATIERE','matieres',23,'Musique (ART)','::1','2026-03-27 21:54:52'),(76,1,'AJOUT MATIERE','matieres',24,'Philosophie (PHI)','::1','2026-03-27 21:55:44'),(77,1,'AJOUT MATIERE','matieres',25,'Statistiques (STA)','::1','2026-03-27 21:56:01'),(78,1,'AJOUT MATIERE','matieres',26,'Geometrie (GE)','::1','2026-03-27 21:56:26'),(79,1,'AJOUT MATIERE','matieres',27,'Trigonometrie (TRIGO)','::1','2026-03-27 21:56:41'),(80,1,'AJOUT MATIERE','matieres',28,'Espagnol (ESP)','::1','2026-03-27 21:57:17'),(81,1,'AJOUT CLASSE','classes',9,'Classe: Antoine Dupre','::1','2026-03-27 21:57:57'),(82,1,'MODIFICATION CLASSE','classes',8,'Classe: Socrate','::1','2026-03-27 21:58:07'),(83,1,'AJOUT CLASSE','classes',10,'Classe: Aristote','::1','2026-03-27 21:58:39'),(84,1,'AJOUT CLASSE','classes',11,'Classe: Victor Hugo','::1','2026-03-27 21:58:58'),(85,1,'AJOUT CLASSE','classes',12,'Classe: Saint Augustin','::1','2026-03-27 22:00:24'),(86,1,'AJOUT CLASSE','classes',13,'Classe: Emmanuel Kant','::1','2026-03-27 22:00:53'),(87,1,'AJOUT CLASSE','classes',14,'Classe: Platon','::1','2026-03-27 22:01:40'),(88,1,'AJOUT ÉLÈVE','eleves',7,'Pierre Jean - Mat: 2026001','::1','2026-03-27 22:07:57'),(89,1,'AJOUT ÉLÈVE','eleves',8,'Rodens Estimable - Mat: 2026002','::1','2026-03-27 22:09:23'),(90,1,'MODIFICATION CLASSE','classes',9,'Classe: 7eme-Antoine Dupre','::1','2026-03-27 22:10:02'),(91,1,'MODIFICATION CLASSE','classes',10,'Classe: 8eme-Aristote','::1','2026-03-27 22:10:14'),(92,1,'MODIFICATION CLASSE','classes',11,'Classe: 9eme-Victor Hugo','::1','2026-03-27 22:10:27'),(93,1,'MODIFICATION CLASSE','classes',8,'Classe: NS1-Socrate','::1','2026-03-27 22:10:38'),(94,1,'MODIFICATION CLASSE','classes',12,'Classe: NS2-Saint Augustin','::1','2026-03-27 22:10:58'),(95,1,'MODIFICATION CLASSE','classes',12,'Classe: NS2-Saint Augustin','::1','2026-03-27 22:11:07'),(96,1,'MODIFICATION CLASSE','classes',12,'Classe: NS2-Saint Augustin','::1','2026-03-27 22:11:13'),(97,1,'MODIFICATION CLASSE','classes',13,'Classe: NS3-Emmanuel Kant','::1','2026-03-27 22:11:27'),(98,1,'MODIFICATION CLASSE','classes',14,'Classe: NS4-Platon','::1','2026-03-27 22:11:43'),(99,1,'AJOUT ÉLÈVE','eleves',9,'roobens Jean - Mat: 2026003','::1','2026-03-27 22:12:51'),(100,1,'AJOUT ÉLÈVE','eleves',10,'Louis Vanessa - Mat: 2026004','::1','2026-03-27 22:15:04'),(101,1,'AJOUT ÉLÈVE','eleves',11,'Joseph Kevin - Mat: 2026005','::1','2026-03-27 22:16:06'),(102,1,'AJOUT ÉLÈVE','eleves',12,'Charles Naomi - Mat: 2026006','::1','2026-03-27 22:18:03'),(103,1,'AJOUT ÉLÈVE','eleves',13,'François Junior - Mat: 2026007','::1','2026-03-27 22:19:07'),(104,1,'AJOUT MATIERE CLASSE','classe_matieres',1,'Classe:9 Mat:15 Barème:300','::1','2026-03-27 22:21:24'),(105,1,'AJOUT MATIERE CLASSE','classe_matieres',2,'Classe:9 Mat:27 Barème:100','::1','2026-03-27 22:21:50'),(106,1,'SUPPRESSION MATIERE CLASSE','classe_matieres',1,'','::1','2026-03-27 22:22:20'),(107,1,'SUPPRESSION MATIERE CLASSE','classe_matieres',2,'','::1','2026-03-27 22:22:26'),(108,1,'AJOUT MATIERE CLASSE','classe_matieres',3,'Classe:9 Mat:14 Barème:200','::1','2026-03-27 22:22:42'),(109,1,'AJOUT MATIERE CLASSE','classe_matieres',4,'Classe:9 Mat:16 Barème:100','::1','2026-03-27 22:22:55'),(110,1,'AJOUT MATIERE CLASSE','classe_matieres',5,'Classe:9 Mat:28 Barème:200','::1','2026-03-27 22:23:16'),(111,1,'AJOUT MATIERE CLASSE','classe_matieres',6,'Classe:9 Mat:26 Barème:100','::1','2026-03-27 22:23:38'),(112,1,'AJOUT MATIERE CLASSE','classe_matieres',7,'Classe:9 Mat:20 Barème:200','::1','2026-03-27 22:23:49'),(113,1,'AJOUT MATIERE CLASSE','classe_matieres',8,'Classe:9 Mat:18 Barème:200','::1','2026-03-27 22:24:05'),(114,1,'SUPPRESSION MATIERE','matieres',21,'Science Experimental','::1','2026-03-27 22:24:54'),(115,1,'AJOUT MATIERE CLASSE','classe_matieres',9,'Classe:10 Mat:14 Barème:200','::1','2026-03-27 22:25:29'),(116,1,'AJOUT MATIERE CLASSE','classe_matieres',10,'Classe:10 Mat:16 Barème:100','::1','2026-03-27 22:25:39'),(117,1,'AJOUT MATIERE CLASSE','classe_matieres',11,'Classe:10 Mat:28 Barème:200','::1','2026-03-27 22:25:52'),(118,1,'AJOUT MATIERE CLASSE','classe_matieres',12,'Classe:10 Mat:26 Barème:200','::1','2026-03-27 22:26:10'),(119,1,'AJOUT MATIERE CLASSE','classe_matieres',13,'Classe:10 Mat:18 Barème:200','::1','2026-03-27 22:26:24'),(120,1,'AJOUT MATIERE CLASSE','classe_matieres',14,'Classe:10 Mat:20 Barème:200','::1','2026-03-27 22:26:34'),(121,1,'AJOUT MATIERE CLASSE','classe_matieres',15,'Classe:11 Mat:14 Barème:200','::1','2026-03-27 22:27:10'),(122,1,'AJOUT MATIERE','matieres',29,'Creole (CRE)','::1','2026-03-27 22:27:28'),(123,1,'AJOUT MATIERE CLASSE','classe_matieres',16,'Classe:9 Mat:29 Barème:200','::1','2026-03-27 22:27:49'),(124,1,'AJOUT MATIERE CLASSE','classe_matieres',17,'Classe:10 Mat:29 Barème:200','::1','2026-03-27 22:28:03'),(125,1,'AJOUT MATIERE CLASSE','classe_matieres',18,'Classe:11 Mat:16 Barème:100','::1','2026-03-27 22:28:45'),(126,1,'AJOUT MATIERE CLASSE','classe_matieres',19,'Classe:11 Mat:18 Barème:200','::1','2026-03-27 22:30:27'),(127,1,'AJOUT MATIERE CLASSE','classe_matieres',20,'Classe:11 Mat:29 Barème:200','::1','2026-03-27 22:30:44'),(128,1,'AJOUT MATIERE CLASSE','classe_matieres',21,'Classe:11 Mat:26 Barème:200','::1','2026-03-27 22:30:56'),(129,1,'AJOUT MATIERE CLASSE','classe_matieres',22,'Classe:11 Mat:28 Barème:200','::1','2026-03-27 22:31:09'),(130,1,'AJOUT MATIERE CLASSE','classe_matieres',23,'Classe:11 Mat:20 Barème:200','::1','2026-03-27 22:31:30'),(131,1,'AJOUT MATIERE CLASSE','classe_matieres',24,'Classe:8 Mat:14 Barème:200','::1','2026-03-27 22:31:53'),(132,1,'AJOUT MATIERE CLASSE','classe_matieres',25,'Classe:8 Mat:16 Barème:100','::1','2026-03-27 22:32:05'),(133,1,'AJOUT MATIERE CLASSE','classe_matieres',26,'Classe:8 Mat:18 Barème:200','::1','2026-03-27 22:32:15'),(134,1,'AJOUT MATIERE CLASSE','classe_matieres',27,'Classe:8 Mat:15 Barème:300','::1','2026-03-27 22:32:22'),(135,1,'AJOUT MATIERE CLASSE','classe_matieres',28,'Classe:8 Mat:29 Barème:200','::1','2026-03-27 22:32:31'),(136,1,'AJOUT MATIERE CLASSE','classe_matieres',29,'Classe:8 Mat:22 Barème:100','::1','2026-03-27 22:32:39'),(137,1,'AJOUT MATIERE CLASSE','classe_matieres',30,'Classe:8 Mat:28 Barème:200','::1','2026-03-27 22:32:47'),(138,1,'AJOUT MATIERE CLASSE','classe_matieres',31,'Classe:8 Mat:17 Barème:200','::1','2026-03-27 22:32:56'),(139,1,'AJOUT MATIERE CLASSE','classe_matieres',32,'Classe:8 Mat:26 Barème:100','::1','2026-03-27 22:33:04'),(140,1,'AJOUT MATIERE CLASSE','classe_matieres',33,'Classe:8 Mat:23 Barème:100','::1','2026-03-27 22:33:10'),(141,1,'AJOUT MATIERE CLASSE','classe_matieres',34,'Classe:8 Mat:20 Barème:200','::1','2026-03-27 22:33:20'),(142,1,'AJOUT MATIERE CLASSE','classe_matieres',35,'Classe:8 Mat:27 Barème:100','::1','2026-03-27 22:33:27'),(143,1,'AJOUT MATIERE CLASSE','classe_matieres',36,'Classe:8 Mat:25 Barème:200','::1','2026-03-27 22:33:40'),(144,1,'ASSIGNATION','professeur_classes',9,'Prof:4 Classe:8 Mat:14','::1','2026-03-27 22:34:39'),(145,1,'ASSIGNATION','professeur_classes',10,'Prof:4 Classe:12 Mat:14','::1','2026-03-27 22:35:01'),(146,1,'ASSIGNATION','professeur_classes',11,'Prof:4 Classe:13 Mat:14','::1','2026-03-27 22:35:13'),(147,1,'ASSIGNATION','professeur_classes',12,'Prof:4 Classe:14 Mat:14','::1','2026-03-27 22:35:25'),(148,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-27 22:35:44'),(149,4,'CONNEXION','utilisateurs',4,'Connexion réussie','::1','2026-03-27 22:35:52'),(150,4,'DECONNEXION','utilisateurs',4,'Déconnexion','::1','2026-03-27 22:37:04'),(151,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-27 22:37:10'),(152,1,'NOUVELLE ANNÉE SCOLAIRE','systeme',NULL,'Passage de 2024-2025 vers 2026-2027 — 0 diplômés, 0 montés, 0 redoublants','::1','2026-03-27 22:40:39'),(153,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-27 22:41:05'),(154,4,'CONNEXION','utilisateurs',4,'Connexion réussie','::1','2026-03-27 22:41:10'),(155,4,'DECONNEXION','utilisateurs',4,'Déconnexion','::1','2026-03-27 22:42:55'),(156,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-27 22:45:31'),(157,1,'SUPPRESSION ASSIGNATION','professeur_classes',9,'','::1','2026-03-28 01:20:23'),(158,1,'SUPPRESSION ASSIGNATION','professeur_classes',11,'','::1','2026-03-28 01:20:33'),(159,1,'SUPPRESSION ASSIGNATION','professeur_classes',10,'','::1','2026-03-28 01:20:36'),(160,1,'SUPPRESSION ASSIGNATION','professeur_classes',18,'','::1','2026-03-28 01:20:39'),(161,1,'SUPPRESSION ASSIGNATION','professeur_classes',19,'','::1','2026-03-28 01:20:42'),(162,1,'SUPPRESSION ASSIGNATION','professeur_classes',12,'','::1','2026-03-28 01:20:47'),(163,1,'SUPPRESSION ASSIGNATION','professeur_classes',17,'','::1','2026-03-28 01:20:51'),(164,1,'SUPPRESSION ASSIGNATION','professeur_classes',20,'','::1','2026-03-28 01:20:54'),(165,1,'MODIFICATION PROFESSEUR','utilisateurs',3,'Joseph Estime','::1','2026-03-28 01:21:26'),(166,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-28 01:24:49'),(167,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-28 01:25:12'),(168,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-28 01:25:34'),(169,2,'CONNEXION','utilisateurs',2,'Connexion réussie','::1','2026-03-28 01:25:40'),(170,2,'DECONNEXION','utilisateurs',2,'Déconnexion','::1','2026-03-28 01:25:53'),(171,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-28 01:25:58'),(172,1,'ASSIGNATION','professeur_classes',21,'Prof:2 Classe:14 Mat:24','::1','2026-03-28 01:26:17'),(173,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-28 01:26:45'),(174,2,'CONNEXION','utilisateurs',2,'Connexion réussie','::1','2026-03-28 01:26:49'),(175,2,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:24 Ctrl:7 — 1 notes (/100)','::1','2026-03-28 01:34:42'),(176,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-28 13:52:31'),(177,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-28 14:08:25'),(178,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-28 14:11:45'),(179,2,'CONNEXION','utilisateurs',2,'Connexion réussie','::1','2026-03-28 14:11:54'),(180,2,'DECONNEXION','utilisateurs',2,'Déconnexion','::1','2026-03-28 14:12:06'),(181,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-28 14:12:17'),(182,1,'ASSIGNATION','professeur_classes',22,'Prof:4 Classe:10 Mat:29','::1','2026-03-28 14:12:57'),(183,1,'ASSIGNATION','professeur_classes',23,'Prof:4 Classe:14 Mat:14','::1','2026-03-28 14:13:19'),(184,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-28 14:13:24'),(185,4,'CONNEXION','utilisateurs',4,'Connexion réussie','::1','2026-03-28 14:13:28'),(186,4,'DECONNEXION','utilisateurs',4,'Déconnexion','::1','2026-03-28 14:38:17'),(187,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-28 14:38:23'),(188,1,'OUVRIR PERIODE SAISIE','periodes_saisie',NULL,'Classe:9 Controle:1 -> ouvert','::1','2026-03-28 14:38:55'),(189,1,'OUVRIR PERIODE SAISIE','periodes_saisie',NULL,'Classe:14 Controle:1 -> ouvert','::1','2026-03-28 14:39:25'),(190,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-28 23:28:48'),(191,4,'CONNEXION','utilisateurs',4,'Connexion réussie','::1','2026-03-28 23:28:54'),(192,4,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:14 Ctrl:1 — 1 notes (/100)','::1','2026-03-28 23:31:12'),(193,4,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:14 Ctrl:1 — 1 notes (/100)','::1','2026-03-28 23:41:47'),(194,4,'DECONNEXION','utilisateurs',4,'Déconnexion','::1','2026-03-28 23:46:32'),(195,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-28 23:46:39'),(196,1,'FERMER_TOUT PERIODES','periodes_saisie',NULL,'Controle:1 -> ferme (toutes classes)','::1','2026-03-29 00:01:23'),(197,1,'OUVRIR_TOUT PERIODES','periodes_saisie',NULL,'Controle:1 -> ouvert (toutes classes)','::1','2026-03-29 00:02:36'),(198,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-29 00:02:42'),(199,4,'CONNEXION','utilisateurs',4,'Connexion réussie','::1','2026-03-29 00:02:47'),(200,4,'DECONNEXION','utilisateurs',4,'Déconnexion','::1','2026-03-29 00:02:59'),(201,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-29 00:03:08'),(202,1,'AJOUT MATIERE CLASSE','classe_matieres',71,'Classe:14 Mat:24 Barème:200','::1','2026-03-29 00:03:27'),(203,1,'AJOUT MATIERE CLASSE','classe_matieres',72,'Classe:14 Mat:19 Barème:200','::1','2026-03-29 00:03:41'),(204,1,'AJOUT MATIERE CLASSE','classe_matieres',73,'Classe:14 Mat:26 Barème:100','::1','2026-03-29 00:03:52'),(205,1,'AJOUT MATIERE CLASSE','classe_matieres',74,'Classe:14 Mat:14 Barème:200','::1','2026-03-29 00:05:25'),(206,1,'AJOUT MATIERE CLASSE','classe_matieres',75,'Classe:14 Mat:16 Barème:100','::1','2026-03-29 00:06:15'),(207,1,'AJOUT MATIERE CLASSE','classe_matieres',76,'Classe:14 Mat:18 Barème:200','::1','2026-03-29 00:06:25'),(208,1,'AJOUT MATIERE CLASSE','classe_matieres',77,'Classe:14 Mat:17 Barème:200','::1','2026-03-29 00:06:33'),(209,1,'AJOUT MATIERE CLASSE','classe_matieres',78,'Classe:14 Mat:15 Barème:300','::1','2026-03-29 00:06:40'),(210,1,'AJOUT MATIERE CLASSE','classe_matieres',79,'Classe:14 Mat:20 Barème:200','::1','2026-03-29 00:06:48'),(211,1,'AJOUT MATIERE CLASSE','classe_matieres',80,'Classe:14 Mat:25 Barème:100','::1','2026-03-29 00:07:01'),(212,1,'AJOUT MATIERE CLASSE','classe_matieres',81,'Classe:14 Mat:29 Barème:200','::1','2026-03-29 00:07:08'),(213,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-29 00:07:23'),(214,4,'CONNEXION','utilisateurs',4,'Connexion réussie','::1','2026-03-29 00:07:28'),(215,4,'DECONNEXION','utilisateurs',4,'Déconnexion','::1','2026-03-29 00:08:07'),(216,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-29 00:08:12'),(217,1,'ASSIGNATION','professeur_classes',24,'Prof:4 Classe:14 Mat:27','::1','2026-03-29 00:09:46'),(218,1,'ASSIGNATION','professeur_classes',25,'Prof:4 Classe:14 Mat:19','::1','2026-03-29 00:10:01'),(219,1,'ASSIGNATION','professeur_classes',26,'Prof:4 Classe:14 Mat:17','::1','2026-03-29 00:10:16'),(220,1,'ASSIGNATION','professeur_classes',27,'Prof:4 Classe:14 Mat:18','::1','2026-03-29 00:10:35'),(221,1,'ASSIGNATION','professeur_classes',28,'Prof:4 Classe:14 Mat:23','::1','2026-03-29 00:10:51'),(222,1,'ASSIGNATION','professeur_classes',29,'Prof:4 Classe:14 Mat:26','::1','2026-03-29 00:11:12'),(223,1,'ASSIGNATION','professeur_classes',30,'Prof:4 Classe:14 Mat:25','::1','2026-03-29 00:11:28'),(224,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-29 00:11:41'),(225,4,'CONNEXION','utilisateurs',4,'Connexion réussie','::1','2026-03-29 00:12:02'),(226,4,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:18 Ctrl:1 — 1 notes (/200)','::1','2026-03-29 00:12:43'),(227,4,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:18 Ctrl:1 — 1 notes (/200)','::1','2026-03-29 00:13:01'),(228,4,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:18 Ctrl:1 — 1 notes (/200)','::1','2026-03-29 00:13:30'),(229,4,'DECONNEXION','utilisateurs',4,'Déconnexion','::1','2026-03-29 00:23:34'),(230,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-29 00:24:03'),(231,1,'ASSIGNATION','professeur_classes',31,'Prof:2 Classe:14 Mat:25','::1','2026-03-29 00:39:29'),(232,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-29 01:03:08'),(233,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-29 01:03:27'),(234,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-29 01:03:51'),(235,4,'CONNEXION','utilisateurs',4,'Connexion réussie','::1','2026-03-29 01:03:58'),(236,4,'SAISIE NOTES','notes',NULL,'Classe:10 Mat:29 Ctrl:1 — 1 notes (/200)','::1','2026-03-29 01:24:48'),(237,4,'SAISIE NOTES','notes',NULL,'Classe:10 Mat:29 Ctrl:1 — 1 notes (/200)','::1','2026-03-29 01:25:53'),(238,4,'SAISIE NOTES','notes',NULL,'Classe:10 Mat:29 Ctrl:1 — 1 notes (/200)','::1','2026-03-29 01:27:01'),(239,4,'SAISIE NOTES','notes',NULL,'Classe:10 Mat:29 Ctrl:1 — 1 notes (/200)','::1','2026-03-29 01:27:11'),(240,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-29 12:36:59'),(241,1,'AUTORISER ACCES BULLETIN','acces_bulletins',13,'Élève:13 → autorise','::1','2026-03-29 12:42:07'),(242,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-29 13:42:58'),(243,1,'FERMER_TOUT PERIODES','periodes_saisie',NULL,'Controle:1 -> ferme (toutes classes)','::1','2026-03-29 14:06:44'),(244,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-29 17:14:54'),(245,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-29 17:18:01'),(246,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-30 01:33:14'),(247,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-30 15:27:08'),(248,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-30 17:32:21'),(249,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-30 17:33:54'),(250,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-31 00:34:26'),(251,1,'MODIFICATION CLASSE','classes',9,'Classe: Antoine Dupre','::1','2026-03-31 00:43:08'),(252,1,'MODIFICATION CLASSE','classes',10,'Classe: Aristote','::1','2026-03-31 00:43:15'),(253,1,'MODIFICATION CLASSE','classes',11,'Classe: Victor Hugo','::1','2026-03-31 00:43:22'),(254,1,'MODIFICATION CLASSE','classes',8,'Classe: Socrate','::1','2026-03-31 00:43:31'),(255,1,'MODIFICATION CLASSE','classes',12,'Classe: Saint Augustin','::1','2026-03-31 00:43:39'),(256,1,'MODIFICATION CLASSE','classes',13,'Classe: Emmanuel Kant','::1','2026-03-31 00:43:49'),(257,1,'MODIFICATION CLASSE','classes',14,'Classe: Platon','::1','2026-03-31 00:43:57'),(258,1,'SUPPRESSION ASSIGNATION','professeur_classes',21,'','::1','2026-03-31 00:47:05'),(259,1,'SUPPRESSION ASSIGNATION','professeur_classes',31,'','::1','2026-03-31 00:47:11'),(260,1,'SUPPRESSION PROFESSEUR','utilisateurs',2,'Jean Pierre','::1','2026-03-31 01:21:43'),(261,1,'SUPPRESSION PROFESSEUR','utilisateurs',3,'Joseph Estime','::1','2026-03-31 01:23:09'),(262,1,'SUPPRESSION PROFESSEUR','utilisateurs',4,'Emmanuel Estimable','::1','2026-03-31 01:25:24'),(263,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-31 01:30:28'),(264,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-31 01:33:10'),(265,1,'CHANGEMENT MOT DE PASSE ECONMAT','utilisateurs',5,'Admin a changé le mot de passe de l\'économat','::1','2026-03-31 01:34:18'),(266,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-31 01:34:42'),(267,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-31 14:09:19'),(268,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-03-31 14:15:52'),(269,6,'CONNEXION','utilisateurs',6,'Connexion réussie','::1','2026-03-31 14:20:05'),(270,6,'AUTORISER ACCES BULLETIN','acces_bulletins',12,'Élève:12 → autorise','::1','2026-03-31 14:21:11'),(271,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-03-31 19:56:16'),(272,1,'AJOUT CLASSE','classes',15,'Classe: Sainte-Therese','::1','2026-03-31 21:07:11'),(273,1,'SUPPRESSION CLASSE','classes',15,'Classe: Sainte-Therese','::1','2026-03-31 21:07:25'),(274,1,'MODIFICATION BAREME','classe_matieres',3,'Nouveau barème: 201','::1','2026-03-31 21:48:30'),(275,1,'MODIFICATION BAREME','classe_matieres',3,'Nouveau barème: 200','::1','2026-03-31 21:48:34'),(276,1,'MODIFICATION BAREME','classe_matieres',3,'Nouveau barème: 199','::1','2026-03-31 21:48:41'),(277,1,'MODIFICATION BAREME','classe_matieres',3,'Nouveau barème: 200','::1','2026-03-31 21:48:45'),(278,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-01 00:51:10'),(279,1,'AJOUT MATIERE CLASSE','classe_matieres',82,'Classe:9 Mat:25 Barème:100','::1','2026-04-01 01:15:06'),(280,1,'FERMER_TOUT PERIODES','periodes_saisie',NULL,'Controle:1 -> ferme (toutes classes)','::1','2026-04-01 01:29:57'),(281,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-01 01:43:36'),(282,6,'CONNEXION','utilisateurs',6,'Connexion réussie','::1','2026-04-01 01:43:42'),(283,6,'BLOQUER ACCES BULLETIN','acces_bulletins',13,'Élève:13 → bloque','::1','2026-04-01 01:45:50'),(284,6,'DECONNEXION','utilisateurs',6,'Déconnexion','::1','2026-04-01 14:12:51'),(285,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-01 14:13:00'),(286,1,'AJOUT PROFESSEUR','utilisateurs',7,'Roobens Estavien','::1','2026-04-01 15:26:13'),(287,1,'AJOUT PROFESSEUR','utilisateurs',8,'Estimable Roseline','::1','2026-04-01 15:28:18'),(288,1,'ASSIGNATION','professeur_classes',32,'Prof:7 Classe:14 Mat:15','::1','2026-04-01 15:28:46'),(289,1,'ASSIGNATION','professeur_classes',33,'Prof:8 Classe:9 Mat:25','::1','2026-04-01 15:29:15'),(290,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-01 15:30:57'),(291,7,'CONNEXION','utilisateurs',7,'Connexion réussie','::1','2026-04-01 15:31:13'),(292,7,'DECONNEXION','utilisateurs',7,'Déconnexion','::1','2026-04-01 15:36:14'),(293,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-01 15:36:19'),(294,1,'IMPORT EXCEL','eleves',NULL,'Import: 0 OK, 20 erreurs','::1','2026-04-01 16:06:26'),(295,1,'IMPORT EXCEL','eleves',NULL,'Import: 0 OK, 20 erreurs','::1','2026-04-01 16:06:42'),(296,1,'IMPORT EXCEL','eleves',NULL,'Import: 0 OK, 20 erreurs','::1','2026-04-01 16:19:17'),(297,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-02 15:28:26'),(298,1,'IMPORT EXCEL','eleves',NULL,'Import: 0 OK, 20 erreurs','::1','2026-04-02 15:29:14'),(299,1,'IMPORT EXCEL','eleves',NULL,'Import: 0 OK, 20 erreurs','::1','2026-04-02 15:29:52'),(300,1,'IMPORT EXCEL','eleves',NULL,'Import: 0 OK, 20 erreurs','::1','2026-04-02 15:30:19'),(301,1,'IMPORT EXCEL','eleves',NULL,'Import: 0 OK, 20 erreurs','::1','2026-04-02 15:31:55'),(302,1,'IMPORT EXCEL','eleves',NULL,'Import: 0 OK, 20 erreurs','::1','2026-04-02 15:33:57'),(303,1,'OUVRIR_TOUT PERIODES','periodes_saisie',NULL,'Controle:1 -> ouvert (toutes classes)','::1','2026-04-02 15:44:00'),(304,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-02 15:44:06'),(305,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-02 15:45:20'),(306,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-02 15:45:34'),(307,7,'CONNEXION','utilisateurs',7,'Connexion réussie','::1','2026-04-02 15:45:38'),(308,7,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:15 Ctrl:1 — 1 notes (/300)','::1','2026-04-02 15:45:58'),(309,7,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:15 Ctrl:1 — 1 notes (/300)','::1','2026-04-02 15:46:11'),(310,7,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:15 Ctrl:1 — 1 notes (/300)','::1','2026-04-02 15:46:21'),(311,7,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:15 Ctrl:1 — 1 notes (/300)','::1','2026-04-02 15:46:48'),(312,7,'DECONNEXION','utilisateurs',7,'Déconnexion','::1','2026-04-02 15:46:57'),(313,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-02 15:47:02'),(314,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-02 15:51:01'),(315,7,'CONNEXION','utilisateurs',7,'Connexion réussie','::1','2026-04-02 15:51:05'),(316,7,'DECONNEXION','utilisateurs',7,'Déconnexion','::1','2026-04-02 15:51:53'),(317,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-02 15:52:00'),(318,1,'OUVRIR_TOUT PERIODES','periodes_saisie',NULL,'Controle:3 -> ouvert (toutes classes)','::1','2026-04-02 15:52:25'),(319,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-02 15:52:30'),(320,7,'CONNEXION','utilisateurs',7,'Connexion réussie','::1','2026-04-02 15:52:35'),(321,7,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:15 Ctrl:3 — 1 notes (/300)','::1','2026-04-02 15:52:51'),(322,7,'DECONNEXION','utilisateurs',7,'Déconnexion','::1','2026-04-02 15:52:59'),(323,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-02 15:53:06'),(324,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-02 20:18:14'),(325,7,'CONNEXION','utilisateurs',7,'Connexion réussie','::1','2026-04-02 20:18:18'),(326,7,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:15 Ctrl:1 — 1 notes (/300)','::1','2026-04-02 20:18:49'),(327,7,'DECONNEXION','utilisateurs',7,'Déconnexion','::1','2026-04-02 20:37:34'),(328,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-02 20:37:38'),(329,1,'IMPORT EXCEL','utilisateurs',NULL,'Import: 1 OK, 1 erreurs','::1','2026-04-02 20:49:34'),(330,1,'SUPPRESSION PROFESSEUR','utilisateurs',9,'Jean ← Exemple (supprimer)','::1','2026-04-02 20:50:07'),(331,1,'IMPORT EXCEL','eleves',NULL,'Import: 11 OK, 8 erreurs','::1','2026-04-02 21:01:30'),(332,1,'IMPORT EXCEL','eleves',NULL,'Import: 0 OK, 13 erreurs','::1','2026-04-02 21:04:13'),(333,1,'IMPORT EXCEL','utilisateurs',NULL,'Import: 12 OK, 1 erreurs','::1','2026-04-02 21:04:30'),(334,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-03 01:48:11'),(335,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-03 12:39:14'),(336,1,'ASSIGNATION','professeur_classes',34,'Prof:21 Classe:14 Mat:25','::1','2026-04-03 12:40:42'),(337,1,'ASSIGNATION','professeur_classes',35,'Prof:12 Classe:14 Mat:27','::1','2026-04-03 12:41:21'),(338,1,'ASSIGNATION','professeur_classes',36,'Prof:20 Classe:14 Mat:23','::1','2026-04-03 12:41:38'),(339,1,'ASSIGNATION','professeur_classes',37,'Prof:14 Classe:14 Mat:20','::1','2026-04-03 12:42:46'),(340,1,'ASSIGNATION','professeur_classes',38,'Prof:15 Classe:14 Mat:17','::1','2026-04-03 12:43:12'),(341,1,'ASSIGNATION','professeur_classes',39,'Prof:10 Classe:14 Mat:18','::1','2026-04-03 12:43:32'),(342,1,'ASSIGNATION','professeur_classes',40,'Prof:19 Classe:14 Mat:29','::1','2026-04-03 12:43:51'),(343,1,'ASSIGNATION','professeur_classes',41,'Prof:13 Classe:14 Mat:19','::1','2026-04-03 12:44:32'),(344,1,'ASSIGNATION','professeur_classes',42,'Prof:11 Classe:14 Mat:28','::1','2026-04-03 12:45:01'),(345,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-03 12:45:35'),(346,7,'CONNEXION','utilisateurs',7,'Connexion réussie','::1','2026-04-03 12:45:45'),(347,7,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:15 Ctrl:1 — 1 notes (/300)','::1','2026-04-03 12:46:03'),(348,7,'DECONNEXION','utilisateurs',7,'Déconnexion','::1','2026-04-03 12:47:21'),(349,10,'CONNEXION','utilisateurs',10,'Connexion réussie','::1','2026-04-03 12:48:05'),(350,10,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:18 Ctrl:1 — 1 notes (/200)','::1','2026-04-03 12:48:41'),(351,10,'DECONNEXION','utilisateurs',10,'Déconnexion','::1','2026-04-03 12:48:50'),(352,11,'CONNEXION','utilisateurs',11,'Connexion réussie','::1','2026-04-03 12:49:14'),(353,11,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:28 Ctrl:1 — 1 notes (/100)','::1','2026-04-03 12:49:31'),(354,11,'DECONNEXION','utilisateurs',11,'Déconnexion','::1','2026-04-03 12:49:46'),(355,12,'CONNEXION','utilisateurs',12,'Connexion réussie','::1','2026-04-03 12:50:12'),(356,12,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:27 Ctrl:1 — 1 notes (/100)','::1','2026-04-03 12:50:34'),(357,12,'DECONNEXION','utilisateurs',12,'Déconnexion','::1','2026-04-03 12:50:40'),(358,13,'CONNEXION','utilisateurs',13,'Connexion réussie','::1','2026-04-03 12:51:03'),(359,13,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:19 Ctrl:1 — 1 notes (/200)','::1','2026-04-03 12:51:29'),(360,13,'DECONNEXION','utilisateurs',13,'Déconnexion','::1','2026-04-03 12:51:37'),(361,14,'CONNEXION','utilisateurs',14,'Connexion réussie','::1','2026-04-03 12:51:56'),(362,14,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:20 Ctrl:1 — 1 notes (/200)','::1','2026-04-03 12:52:14'),(363,14,'DECONNEXION','utilisateurs',14,'Déconnexion','::1','2026-04-03 12:52:26'),(364,15,'CONNEXION','utilisateurs',15,'Connexion réussie','::1','2026-04-03 12:52:38'),(365,15,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:17 Ctrl:1 — 1 notes (/200)','::1','2026-04-03 12:52:58'),(366,15,'DECONNEXION','utilisateurs',15,'Déconnexion','::1','2026-04-03 12:53:04'),(367,16,'CONNEXION','utilisateurs',16,'Connexion réussie','::1','2026-04-03 12:53:33'),(368,16,'DECONNEXION','utilisateurs',16,'Déconnexion','::1','2026-04-03 12:53:41'),(369,21,'CONNEXION','utilisateurs',21,'Connexion réussie','::1','2026-04-03 12:54:07'),(370,21,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:25 Ctrl:1 — 1 notes (/100)','::1','2026-04-03 12:54:21'),(371,21,'DECONNEXION','utilisateurs',21,'Déconnexion','::1','2026-04-03 12:54:29'),(372,20,'CONNEXION','utilisateurs',20,'Connexion réussie','::1','2026-04-03 12:54:47'),(373,20,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:23 Ctrl:1 — 1 notes (/100)','::1','2026-04-03 12:55:09'),(374,20,'DECONNEXION','utilisateurs',20,'Déconnexion','::1','2026-04-03 12:55:15'),(375,19,'CONNEXION','utilisateurs',19,'Connexion réussie','::1','2026-04-03 12:55:34'),(376,19,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:29 Ctrl:1 — 1 notes (/200)','::1','2026-04-03 12:55:52'),(377,19,'DECONNEXION','utilisateurs',19,'Déconnexion','::1','2026-04-03 12:55:57'),(378,17,'CONNEXION','utilisateurs',17,'Connexion réussie','::1','2026-04-03 12:56:30'),(379,17,'DECONNEXION','utilisateurs',17,'Déconnexion','::1','2026-04-03 12:56:36'),(380,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-03 12:56:44'),(381,1,'FERMER PERIODE SAISIE','periodes_saisie',NULL,'Classe:9 Controle:1 -> ferme','::1','2026-04-03 14:44:45'),(382,1,'OUVRIR PERIODE SAISIE','periodes_saisie',NULL,'Classe:9 Controle:1 -> ouvert','::1','2026-04-03 14:44:54'),(383,1,'FERMER PERIODE SAISIE','periodes_saisie',NULL,'Classe:9 Controle:1 -> ferme','::1','2026-04-03 14:46:14'),(384,1,'IMPORT EXCEL','eleves',NULL,'Import: 0 OK, 13 erreurs','::1','2026-04-03 14:54:39'),(385,1,'OUVRIR_TOUT PERIODES','periodes_saisie',NULL,'Controle:1 -> ouvert (toutes classes)','::1','2026-04-03 14:58:16'),(386,1,'OUVRIR_TOUT PERIODES','periodes_saisie',NULL,'Controle:2 -> ouvert (toutes classes)','::1','2026-04-03 14:58:37'),(387,1,'OUVRIR_TOUT PERIODES','periodes_saisie',NULL,'Controle:3 -> ouvert (toutes classes)','::1','2026-04-03 14:58:42'),(388,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-03 15:00:17'),(389,6,'CONNEXION','utilisateurs',6,'Connexion réussie','::1','2026-04-03 15:00:23'),(390,6,'AUTORISER ACCES BULLETIN','acces_bulletins',13,'Élève:13 → autorise','::1','2026-04-03 15:00:54'),(391,6,'CONNEXION','utilisateurs',6,'Connexion réussie','::1','2026-04-03 15:15:57'),(392,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-04 22:18:11'),(393,1,'MODIFICATION BAREME','classe_matieres',7,'Nouveau barème: 201','::1','2026-04-04 22:22:09'),(394,1,'MODIFICATION BAREME','classe_matieres',7,'Nouveau barème: 200','::1','2026-04-04 22:22:12'),(395,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-04 22:40:34'),(396,6,'CONNEXION','utilisateurs',6,'Connexion réussie','::1','2026-04-04 22:40:38'),(397,6,'DECONNEXION','utilisateurs',6,'Déconnexion','::1','2026-04-04 23:32:33'),(398,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-04 23:32:40'),(399,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-05 00:32:23'),(400,7,'CONNEXION','utilisateurs',7,'Connexion réussie','::1','2026-04-05 00:32:29'),(401,7,'DECONNEXION','utilisateurs',7,'Déconnexion','::1','2026-04-05 00:33:25'),(402,6,'CONNEXION','utilisateurs',6,'Connexion réussie','::1','2026-04-05 00:33:36'),(403,6,'AUTORISER ACCES','acces_bulletins',21,'','::1','2026-04-05 00:33:53'),(404,6,'AUTORISER ACCES','acces_bulletins',15,'','::1','2026-04-05 00:33:55'),(405,6,'DECONNEXION','utilisateurs',6,'Déconnexion','::1','2026-04-05 00:35:28'),(406,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-05 00:35:33'),(407,1,'AJOUT ÉLÈVE','eleves',25,'Jean Isaac - Mat: 2026008','::1','2026-04-05 00:41:26'),(408,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-05 01:14:58'),(409,7,'CONNEXION','utilisateurs',7,'Connexion réussie','::1','2026-04-05 01:15:05'),(410,7,'CONNEXION','utilisateurs',7,'Connexion réussie','::1','2026-04-05 16:18:10'),(411,7,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:15 Ctrl:1 — 1 notes (/300)','::1','2026-04-05 17:11:15'),(412,7,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:15 Ctrl:1 — 2 notes (/300)','::1','2026-04-05 17:11:26'),(413,7,'DECONNEXION','utilisateurs',7,'Déconnexion','::1','2026-04-05 17:49:36'),(414,6,'CONNEXION','utilisateurs',6,'Connexion réussie','::1','2026-04-05 17:49:42'),(415,6,'BLOQUER_CLASSE','acces_bulletins',NULL,'Classe:9','::1','2026-04-05 17:53:20'),(416,6,'DECONNEXION','utilisateurs',6,'Déconnexion','::1','2026-04-05 17:55:46'),(417,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-05 17:55:50'),(418,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-06 14:24:16'),(419,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-06 18:16:38'),(420,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-06 18:18:13'),(421,7,'CONNEXION','utilisateurs',7,'Connexion réussie','::1','2026-04-06 18:18:18'),(422,7,'DECONNEXION','utilisateurs',7,'Déconnexion','::1','2026-04-06 18:18:46'),(423,6,'CONNEXION','utilisateurs',6,'Connexion réussie','::1','2026-04-06 18:19:00'),(424,6,'AUTORISER ACCES','acces_bulletins',9,'','::1','2026-04-06 18:19:46'),(425,6,'DECONNEXION','utilisateurs',6,'Déconnexion','::1','2026-04-06 18:20:50'),(426,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-06 18:20:57'),(427,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-06 19:33:47'),(428,1,'AJOUT MATIERE','matieres',30,'Reseaux (RES)','::1','2026-04-06 19:35:02'),(429,1,'AJOUT MATIERE CLASSE','classe_matieres',83,'Classe:14 Mat:30 Barème:100','::1','2026-04-06 19:35:51'),(430,1,'AJOUT ÉLÈVE','eleves',26,'Asley Jean - Mat: 2026009','::1','2026-04-06 19:37:02'),(431,1,'AJOUT PROFESSEUR','utilisateurs',22,'Mesidor Carlot','::1','2026-04-06 19:38:08'),(432,1,'ASSIGNATION','professeur_classes',43,'Prof:22 Classe:14 Mat:14','::1','2026-04-06 19:38:43'),(433,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-06 19:39:05'),(434,22,'CONNEXION','utilisateurs',22,'Connexion réussie','::1','2026-04-06 19:39:25'),(435,22,'SAISIE NOTES','notes',NULL,'Classe:14 Mat:14 Ctrl:1 — 3 notes (/200)','::1','2026-04-06 19:40:14'),(436,22,'DECONNEXION','utilisateurs',22,'Déconnexion','::1','2026-04-06 19:40:28'),(437,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-06 19:40:31'),(438,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-07 11:16:28'),(439,1,'MODIFICATION ÉLÈVE','eleves',12,'Charles Naomi','::1','2026-04-07 11:47:19'),(440,1,'ASSIGNATION','professeur_classes',44,'Prof:22 Classe:13 Mat:27','::1','2026-04-07 12:26:28'),(441,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-07 12:45:06'),(442,7,'CONNEXION','utilisateurs',7,'Connexion réussie','::1','2026-04-07 12:45:11'),(443,7,'DECONNEXION','utilisateurs',7,'Déconnexion','::1','2026-04-07 12:48:25'),(444,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-07 12:48:30'),(445,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-07 16:09:56'),(446,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-07 16:10:08'),(447,7,'CONNEXION','utilisateurs',7,'Connexion réussie','::1','2026-04-07 16:10:13'),(448,7,'DECONNEXION','utilisateurs',7,'Déconnexion','::1','2026-04-07 16:10:22'),(449,7,'CONNEXION','utilisateurs',7,'Connexion réussie','::1','2026-04-07 16:10:25'),(450,7,'DECONNEXION','utilisateurs',7,'Déconnexion','::1','2026-04-07 16:12:35'),(451,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-07 16:12:40'),(452,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-07 16:13:42'),(453,7,'CONNEXION','utilisateurs',7,'Connexion réussie','::1','2026-04-07 16:13:45'),(454,7,'DECONNEXION','utilisateurs',7,'Déconnexion','::1','2026-04-07 16:15:54'),(455,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-07 16:15:58'),(456,1,'FERMER PERIODE SAISIE','periodes_saisie',NULL,'Classe:14 Controle:1 -> ferme','::1','2026-04-07 16:16:14'),(457,1,'DECONNEXION','utilisateurs',1,'Déconnexion','::1','2026-04-07 16:16:50'),(458,7,'CONNEXION','utilisateurs',7,'Connexion réussie','::1','2026-04-07 16:16:54'),(459,7,'DECONNEXION','utilisateurs',7,'Déconnexion','::1','2026-04-07 16:36:23'),(460,1,'CONNEXION','utilisateurs',1,'Connexion réussie','::1','2026-04-07 16:36:29'),(461,1,'BACKUP','systeme',NULL,'Sauvegarde créée','::1','2026-04-07 17:03:38'),(462,1,'BACKUP','systeme',NULL,'Sauvegarde créée','::1','2026-04-07 17:09:43'),(463,1,'BACKUP','systeme',NULL,'Sauvegarde créée','::1','2026-04-07 17:09:50'),(464,1,'BACKUP','systeme',NULL,'Sauvegarde créée','::1','2026-04-07 17:17:21'),(465,1,'BACKUP','systeme',NULL,'Sauvegarde créée','::1','2026-04-07 17:18:46');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matieres`
--

DROP TABLE IF EXISTS `matieres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matieres` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `code` varchar(20) DEFAULT NULL,
  `coefficient` int NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_nom` (`nom`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matieres`
--

LOCK TABLES `matieres` WRITE;
/*!40000 ALTER TABLE `matieres` DISABLE KEYS */;
INSERT INTO `matieres` VALUES (16,'Bible','BIB',100,'2026-03-27 12:58:29','2026-03-27 12:58:29'),(17,'Geologie','GEO',200,'2026-03-27 12:59:15','2026-03-27 12:59:15'),(18,'Biologie','BIO',200,'2026-03-27 12:59:33','2026-03-27 12:59:33'),(15,'Chimie','CHI',300,'2026-03-27 12:49:28','2026-03-27 12:49:28'),(20,'Science Social','SCS',1,'2026-03-27 21:53:14','2026-03-27 21:53:14'),(19,'Nombre Complexe','NC',200,'2026-03-27 13:00:18','2026-03-27 13:00:18'),(14,'Anglais','ANG',100,'2026-03-27 12:46:49','2026-03-27 12:46:49'),(29,'Creole','CRE',1,'2026-03-27 22:27:28','2026-03-27 22:27:28'),(22,'Education Physique Sportive','EPS',1,'2026-03-27 21:54:41','2026-03-27 21:54:41'),(23,'Musique','ART',1,'2026-03-27 21:54:52','2026-03-27 21:54:52'),(24,'Philosophie','PHI',1,'2026-03-27 21:55:44','2026-03-27 21:55:44'),(25,'Statistiques','STA',1,'2026-03-27 21:56:01','2026-03-27 21:56:01'),(26,'Geometrie','GE',1,'2026-03-27 21:56:26','2026-03-27 21:56:26'),(27,'Trigonometrie','TRIGO',1,'2026-03-27 21:56:41','2026-03-27 21:56:41'),(28,'Espagnol','ESP',1,'2026-03-27 21:57:17','2026-03-27 21:57:17'),(30,'Reseaux','RES',1,'2026-04-06 19:35:02','2026-04-06 19:35:02');
/*!40000 ALTER TABLE `matieres` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `before_delete_matiere` BEFORE DELETE ON `matieres` FOR EACH ROW BEGIN
    DECLARE note_count INT;
    SELECT COUNT(*) INTO note_count FROM notes WHERE matiere_id = OLD.id;
    IF note_count > 0 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'ATANSYON: Matye sa gen not. Ou pa ka efase l.';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `moyennes_finales`
--

DROP TABLE IF EXISTS `moyennes_finales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `moyennes_finales` (
  `id` int NOT NULL AUTO_INCREMENT,
  `eleve_id` int NOT NULL,
  `annee_scolaire` varchar(20) NOT NULL,
  `moyenne_finale` decimal(4,2) NOT NULL,
  `decision` enum('Admis','Repran Klas') NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_finale` (`eleve_id`,`annee_scolaire`),
  KEY `idx_decision` (`decision`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moyennes_finales`
--

LOCK TABLES `moyennes_finales` WRITE;
/*!40000 ALTER TABLE `moyennes_finales` DISABLE KEYS */;
INSERT INTO `moyennes_finales` VALUES (1,1,'2024-2025',0.00,'','2026-03-26 23:18:47'),(2,13,'2024-2025',2.21,'','2026-04-02 15:53:34');
/*!40000 ALTER TABLE `moyennes_finales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moyennes_periode`
--

DROP TABLE IF EXISTS `moyennes_periode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `moyennes_periode` (
  `id` int NOT NULL AUTO_INCREMENT,
  `eleve_id` int NOT NULL,
  `controle_id` int NOT NULL,
  `moyenne` decimal(4,2) NOT NULL,
  `rang` int DEFAULT NULL,
  `calcule_le` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_moyenne` (`eleve_id`,`controle_id`),
  KEY `controle_id` (`controle_id`),
  KEY `idx_eleve_controle` (`eleve_id`,`controle_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moyennes_periode`
--

LOCK TABLES `moyennes_periode` WRITE;
/*!40000 ALTER TABLE `moyennes_periode` DISABLE KEYS */;
/*!40000 ALTER TABLE `moyennes_periode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `eleve_id` int NOT NULL,
  `matiere_id` int NOT NULL,
  `controle_id` int NOT NULL,
  `note` decimal(10,2) DEFAULT NULL,
  `professeur_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_note` (`eleve_id`,`matiere_id`,`controle_id`),
  KEY `professeur_id` (`professeur_id`),
  KEY `idx_eleve` (`eleve_id`),
  KEY `idx_controle` (`controle_id`),
  KEY `idx_matiere` (`matiere_id`),
  CONSTRAINT `notes_chk_1` CHECK (((`note` >= 0) and (`note` <= 9999)))
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` VALUES (4,13,14,1,70.00,22,'2026-03-28 23:31:12','2026-04-06 19:40:14'),(3,13,24,7,8.00,2,'2026-03-28 01:34:42','2026-03-28 01:34:42'),(5,13,18,1,127.00,10,'2026-03-29 00:12:43','2026-04-03 12:48:41'),(6,12,29,1,99.99,4,'2026-03-29 01:24:48','2026-03-29 01:27:11'),(7,13,15,1,230.00,7,'2026-04-02 15:45:58','2026-04-05 17:11:26'),(8,13,15,3,99.99,7,'2026-04-02 15:52:51','2026-04-02 15:52:51'),(9,13,28,1,67.00,11,'2026-04-03 12:49:31','2026-04-03 12:49:31'),(10,13,27,1,45.00,12,'2026-04-03 12:50:34','2026-04-03 12:50:34'),(11,13,19,1,110.00,13,'2026-04-03 12:51:29','2026-04-03 12:51:29'),(12,13,20,1,178.00,14,'2026-04-03 12:52:14','2026-04-03 12:52:14'),(13,13,17,1,164.00,15,'2026-04-03 12:52:58','2026-04-03 12:52:58'),(14,13,25,1,76.00,21,'2026-04-03 12:54:21','2026-04-03 12:54:21'),(15,13,23,1,37.00,20,'2026-04-03 12:55:08','2026-04-03 12:55:08'),(16,13,29,1,123.00,19,'2026-04-03 12:55:52','2026-04-03 12:55:52'),(17,25,15,1,211.00,7,'2026-04-05 17:11:26','2026-04-05 17:11:26'),(18,26,14,1,50.00,22,'2026-04-06 19:40:14','2026-04-06 19:40:14'),(19,25,14,1,20.00,22,'2026-04-06 19:40:14','2026-04-06 19:40:14');
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `periodes_saisie`
--

DROP TABLE IF EXISTS `periodes_saisie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `periodes_saisie` (
  `id` int NOT NULL AUTO_INCREMENT,
  `classe_id` int NOT NULL,
  `controle_id` int NOT NULL,
  `statut` enum('ouvert','ferme') NOT NULL DEFAULT 'ferme',
  `ouvert_le` datetime DEFAULT NULL,
  `ferme_le` datetime DEFAULT NULL,
  `ouvert_par` int DEFAULT NULL,
  `ferme_par` int DEFAULT NULL,
  `note_admin` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_classe_controle` (`classe_id`,`controle_id`),
  KEY `idx_statut` (`statut`),
  KEY `idx_classe` (`classe_id`),
  KEY `idx_controle` (`controle_id`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `periodes_saisie`
--

LOCK TABLES `periodes_saisie` WRITE;
/*!40000 ALTER TABLE `periodes_saisie` DISABLE KEYS */;
INSERT INTO `periodes_saisie` VALUES (1,14,1,'ferme','2026-04-03 10:58:16','2026-04-07 12:16:14',1,1,NULL,'2026-03-28 14:37:27','2026-04-07 16:16:14'),(2,13,1,'ouvert','2026-04-03 10:58:16',NULL,1,1,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:16'),(3,12,1,'ouvert','2026-04-03 10:58:16',NULL,1,1,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:16'),(4,11,1,'ouvert','2026-04-03 10:58:16',NULL,1,1,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:16'),(5,10,1,'ouvert','2026-04-03 10:58:16',NULL,1,1,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:16'),(6,9,1,'ouvert','2026-04-03 10:58:16',NULL,1,1,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:16'),(7,8,1,'ouvert','2026-04-03 10:58:16',NULL,1,1,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:16'),(8,14,2,'ouvert','2026-04-03 10:58:37',NULL,1,NULL,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:37'),(9,13,2,'ouvert','2026-04-03 10:58:37',NULL,1,NULL,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:37'),(10,12,2,'ouvert','2026-04-03 10:58:37',NULL,1,NULL,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:37'),(11,11,2,'ouvert','2026-04-03 10:58:37',NULL,1,NULL,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:37'),(12,10,2,'ouvert','2026-04-03 10:58:37',NULL,1,NULL,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:37'),(13,9,2,'ouvert','2026-04-03 10:58:37',NULL,1,NULL,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:37'),(14,8,2,'ouvert','2026-04-03 10:58:37',NULL,1,NULL,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:37'),(15,14,3,'ouvert','2026-04-03 10:58:42',NULL,1,NULL,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:42'),(16,13,3,'ouvert','2026-04-03 10:58:42',NULL,1,NULL,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:42'),(17,12,3,'ouvert','2026-04-03 10:58:42',NULL,1,NULL,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:42'),(18,11,3,'ouvert','2026-04-03 10:58:42',NULL,1,NULL,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:42'),(19,10,3,'ouvert','2026-04-03 10:58:42',NULL,1,NULL,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:42'),(20,9,3,'ouvert','2026-04-03 10:58:42',NULL,1,NULL,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:42'),(21,8,3,'ouvert','2026-04-03 10:58:42',NULL,1,NULL,NULL,'2026-03-28 14:37:27','2026-04-03 14:58:42'),(22,14,4,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(23,13,4,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(24,12,4,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(25,11,4,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(26,10,4,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(27,9,4,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(28,8,4,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(29,14,5,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(30,13,5,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(31,12,5,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(32,11,5,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(33,10,5,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(34,9,5,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(35,8,5,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(36,14,6,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(37,13,6,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(38,12,6,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(39,11,6,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(40,10,6,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(41,9,6,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(42,8,6,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(43,14,7,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(44,13,7,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(45,12,7,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(46,11,7,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(47,10,7,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(48,9,7,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(49,8,7,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(50,14,8,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(51,13,8,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(52,12,8,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(53,11,8,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(54,10,8,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(55,9,8,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(56,8,8,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(57,14,9,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(58,13,9,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(59,12,9,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(60,11,9,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(61,10,9,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(62,9,9,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27'),(63,8,9,'ferme',NULL,NULL,NULL,NULL,NULL,'2026-03-28 14:37:27','2026-03-28 14:37:27');
/*!40000 ALTER TABLE `periodes_saisie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `professeur_classes`
--

DROP TABLE IF EXISTS `professeur_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `professeur_classes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `professeur_id` int NOT NULL,
  `classe_id` int NOT NULL,
  `matiere_id` int NOT NULL,
  `annee_scolaire` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_assignment` (`professeur_id`,`classe_id`,`matiere_id`,`annee_scolaire`),
  KEY `classe_id` (`classe_id`),
  KEY `matiere_id` (`matiere_id`),
  KEY `idx_prof_annee` (`professeur_id`,`annee_scolaire`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `professeur_classes`
--

LOCK TABLES `professeur_classes` WRITE;
/*!40000 ALTER TABLE `professeur_classes` DISABLE KEYS */;
INSERT INTO `professeur_classes` VALUES (42,11,14,28,'2024-2025','2026-04-03 12:45:01'),(44,22,13,27,'2024-2025','2026-04-07 12:26:28'),(41,13,14,19,'2024-2025','2026-04-03 12:44:32'),(40,19,14,29,'2024-2025','2026-04-03 12:43:51'),(39,10,14,18,'2024-2025','2026-04-03 12:43:32'),(43,22,14,14,'2024-2025','2026-04-06 19:38:43'),(38,15,14,17,'2024-2025','2026-04-03 12:43:12'),(37,14,14,20,'2024-2025','2026-04-03 12:42:46'),(36,20,14,23,'2024-2025','2026-04-03 12:41:38'),(35,12,14,27,'2024-2025','2026-04-03 12:41:21'),(34,21,14,25,'2024-2025','2026-04-03 12:40:42'),(33,8,9,25,'2024-2025','2026-04-01 15:29:14'),(32,7,14,15,'2024-2025','2026-04-01 15:28:46');
/*!40000 ALTER TABLE `professeur_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilisateurs`
--

DROP TABLE IF EXISTS `utilisateurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `utilisateurs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','professeur','econmat') NOT NULL DEFAULT 'professeur',
  `telephone` varchar(20) DEFAULT NULL,
  `adresse` text,
  `status` enum('actif','inactif') DEFAULT 'actif',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilisateurs`
--

LOCK TABLES `utilisateurs` WRITE;
/*!40000 ALTER TABLE `utilisateurs` DISABLE KEYS */;
INSERT INTO `utilisateurs` VALUES (1,'Administration','Système','admin@cst.edu','$2y$10$6AOTreIbaLVfmj43S8X3I.Jy3eU2kU8Y68JM8eIURT33PTeTsKmWi','admin','509-0000-0000',NULL,'actif','2026-03-26 16:45:36','2026-03-31 00:31:22'),(8,'Roseline','Estimable','estimableroseline@gmail.com','$2y$10$gdiROXjjFpthxDwzpUoCmONYiIdzZDbdEvEHFfyBmmsnBR3fgDOki','professeur','32113660','','actif','2026-04-01 15:28:18','2026-04-01 15:28:18'),(6,'Économat','CST','econmat@cst.edu','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','econmat',NULL,NULL,'actif','2026-03-31 14:19:22','2026-03-31 14:19:22'),(7,'Estavien','Roobens','estavienroobens2005@gmail.com','$2y$10$mG90.UHrEodVewpfFZSriOKTIN5LU2.MEl8bSd56K0CocUOW8rni2','professeur','33131807','','actif','2026-04-01 15:26:13','2026-04-01 15:26:13'),(10,'JOSEPH','Jean-Baptiste','jean-baptiste.joseph@comep.edu','$2y$10$Ayo0Fc.5PHC7OjfvPNXOk.poO0uWsD9dENXCJhDG0qvaWtSyiK.4u','professeur','509-3654-1278','Rue Principale, Port-Margot','actif','2026-04-02 21:04:29','2026-04-02 21:04:29'),(11,'PIERRE','Roseline','roseline.pierre@comep.edu','$2y$10$pSqV8.iPYQ5g1JXxzhtGeupWEdvuVllQnl/8.ll8OrmnIK4XLMsb.','professeur','509-3781-2345','Bord de Mer, Port-Margot','actif','2026-04-02 21:04:29','2026-04-02 21:04:29'),(12,'BAPTISTE','Willy','willy.baptiste@comep.edu','$2y$10$TTQzu7CGYuFsabFgM4LaQeodAULExnjAAN3t8yyLsX.sg2glplbR.','professeur','509-3892-3456','Rue 14, Cap-Haïtien','actif','2026-04-02 21:04:29','2026-04-02 21:04:29'),(13,'NICOLAS','Farah','farah.nicolas@comep.edu','$2y$10$2HtWzQ.k8v6LBv8SzuQl5.Pw8gRWSiK9SopC5zxAScrvl0kGtCgbe','professeur','509-3623-4567','Quartier Haut, Port-Margot','actif','2026-04-02 21:04:29','2026-04-02 21:04:29'),(14,'DORSAINT','Robenson','robenson.dorsaint@comep.edu','$2y$10$YDwZfaG15pMKUr1K2k5FS.3zHWEzOmyoXS0AZPCi40bGsjx7BO5TO','professeur','509-3734-5678','Limonade, Nord','actif','2026-04-02 21:04:29','2026-04-02 21:04:29'),(15,'ÉTIENNE','Patrick','patrick.etienne@comep.edu','$2y$10$4.QPLQiIhH5r7mVf9IBgVePMG093jj9mYiymBemFHsSm4Cf8DQYiq','professeur','509-3845-6789','Avenue B, Cap-Haïtien','actif','2026-04-02 21:04:29','2026-04-02 21:04:29'),(16,'MICHAUD','Frantz','frantz.michaud@comep.edu','$2y$10$9EKrw84MqSzD2xXHxMaHm.sFg5N2NH5Xql6qTjIqIsLtHBqqhvcZu','professeur','509-3756-7890','Milot, Nord','actif','2026-04-02 21:04:29','2026-04-02 21:04:29'),(17,'SAINT-FLEUR','Rosemide','rosemide.saintfleur@comep.edu','$2y$10$7mNXkqRyC1GOEc.5zMR7ROph6vNcH1CZn1ov54sAziJiqQ4kfwITu','professeur','509-3867-8901','Morne Vert, Port-Margot','actif','2026-04-02 21:04:29','2026-04-02 21:04:29'),(18,'MOREAU','Ensley','ensley.moreau@comep.edu','$2y$10$BNSzzunlfHhTzWKVN1TfQufjHxzubtB40QUxxO1eKmuIKvq/jekbC','professeur','509-3678-9012','Quartier Morin, Cap-Haïtien','actif','2026-04-02 21:04:29','2026-04-02 21:04:29'),(19,'LAFLEUR','Mirlande','mirlande.lafleur@comep.edu','$2y$10$yPXsC2QC1VgQp..Gcr7aPuoANnrN.tQ2MBdZvjzpR6g5/MWSKRQXC','professeur','509-3789-0123','Rue Commerce, Port-Margot','actif','2026-04-02 21:04:30','2026-04-02 21:04:30'),(20,'CLERVIL','Widlove','widlove.clervil@comep.edu','$2y$10$R6gUrLsRwitIoNRMpJI6ZeB0EanR54k7NshsQQwt/CrDk3gO7ZlHO','professeur','509-3890-1234','Rue 17, Cap-Haïtien','actif','2026-04-02 21:04:30','2026-04-02 21:04:30'),(21,'AUGUSTIN','Nathalie','nathalie.augustin@comep.edu','$2y$10$vmKy18Xo3EA8/sduRSOlkuNxT/60.x5fN1sJs/hwUHK9lXZUKWj3W','professeur','509-3601-2345','Bas Bord, Port-Margot','actif','2026-04-02 21:04:30','2026-04-02 21:04:30'),(22,'Carlot','Mesidor','carlot@gmail.com','$2y$10$qCAcTTgJePd/ZVaS3l7HQO1JAK77HyoLaLZ8/SDb9.DFJmjAOFBmS','professeur','33131807','','actif','2026-04-06 19:38:08','2026-04-06 19:38:08');
/*!40000 ALTER TABLE `utilisateurs` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `before_delete_professeur` BEFORE DELETE ON `utilisateurs` FOR EACH ROW BEGIN
    DECLARE assignment_count INT;
    IF OLD.role = 'professeur' THEN
        SELECT COUNT(*) INTO assignment_count FROM professeur_classes WHERE professeur_id = OLD.id;
        IF assignment_count > 0 THEN
            SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'ATANSYON: Pwofesè sa gen klas asiyen. Retire asiyasyon yo anvan ou efase l.';
        END IF;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary view structure for view `v_eleves_classes`
--

DROP TABLE IF EXISTS `v_eleves_classes`;
/*!50001 DROP VIEW IF EXISTS `v_eleves_classes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_eleves_classes` AS SELECT 
 1 AS `id`,
 1 AS `matricule`,
 1 AS `nom`,
 1 AS `prenom`,
 1 AS `sexe`,
 1 AS `date_naissance`,
 1 AS `lieu_naissance`,
 1 AS `adresse`,
 1 AS `telephone_parent`,
 1 AS `classe_id`,
 1 AS `annee_scolaire`,
 1 AS `status`,
 1 AS `created_at`,
 1 AS `updated_at`,
 1 AS `classe_nom`,
 1 AS `classe_niveau`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_professeurs_assignments`
--

DROP TABLE IF EXISTS `v_professeurs_assignments`;
/*!50001 DROP VIEW IF EXISTS `v_professeurs_assignments`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_professeurs_assignments` AS SELECT 
 1 AS `professeur_id`,
 1 AS `nom`,
 1 AS `prenom`,
 1 AS `email`,
 1 AS `telephone`,
 1 AS `classe_nom`,
 1 AS `matiere_nom`,
 1 AS `coefficient`,
 1 AS `annee_scolaire`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_resultats_final`
--

DROP TABLE IF EXISTS `v_resultats_final`;
/*!50001 DROP VIEW IF EXISTS `v_resultats_final`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_resultats_final` AS SELECT 
 1 AS `eleve_id`,
 1 AS `matricule`,
 1 AS `nom`,
 1 AS `prenom`,
 1 AS `klas`,
 1 AS `moyenne_finale`,
 1 AS `decision`,
 1 AS `annee_scolaire`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_stats_classes`
--

DROP TABLE IF EXISTS `v_stats_classes`;
/*!50001 DROP VIEW IF EXISTS `v_stats_classes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_stats_classes` AS SELECT 
 1 AS `id`,
 1 AS `nom`,
 1 AS `niveau`,
 1 AS `capacite`,
 1 AS `total_eleves`,
 1 AS `places_restantes`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `v_eleves_classes`
--

/*!50001 DROP VIEW IF EXISTS `v_eleves_classes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_eleves_classes` AS select `e`.`id` AS `id`,`e`.`matricule` AS `matricule`,`e`.`nom` AS `nom`,`e`.`prenom` AS `prenom`,`e`.`sexe` AS `sexe`,`e`.`date_naissance` AS `date_naissance`,`e`.`lieu_naissance` AS `lieu_naissance`,`e`.`adresse` AS `adresse`,`e`.`telephone_parent` AS `telephone_parent`,`e`.`classe_id` AS `classe_id`,`e`.`annee_scolaire` AS `annee_scolaire`,`e`.`status` AS `status`,`e`.`created_at` AS `created_at`,`e`.`updated_at` AS `updated_at`,`c`.`nom` AS `classe_nom`,`c`.`niveau` AS `classe_niveau` from (`eleves` `e` left join `classes` `c` on((`e`.`classe_id` = `c`.`id`))) where (`e`.`status` = 'actif') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_professeurs_assignments`
--

/*!50001 DROP VIEW IF EXISTS `v_professeurs_assignments`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_professeurs_assignments` AS select `u`.`id` AS `professeur_id`,`u`.`nom` AS `nom`,`u`.`prenom` AS `prenom`,`u`.`email` AS `email`,`u`.`telephone` AS `telephone`,`c`.`nom` AS `classe_nom`,`m`.`nom` AS `matiere_nom`,`m`.`coefficient` AS `coefficient`,`pc`.`annee_scolaire` AS `annee_scolaire` from (((`professeur_classes` `pc` join `utilisateurs` `u` on((`pc`.`professeur_id` = `u`.`id`))) join `classes` `c` on((`pc`.`classe_id` = `c`.`id`))) join `matieres` `m` on((`pc`.`matiere_id` = `m`.`id`))) where ((`u`.`role` = 'professeur') and (`u`.`status` = 'actif')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_resultats_final`
--

/*!50001 DROP VIEW IF EXISTS `v_resultats_final`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_resultats_final` AS select `e`.`id` AS `eleve_id`,`e`.`matricule` AS `matricule`,`e`.`nom` AS `nom`,`e`.`prenom` AS `prenom`,`c`.`nom` AS `klas`,`mf`.`moyenne_finale` AS `moyenne_finale`,`mf`.`decision` AS `decision`,`mf`.`annee_scolaire` AS `annee_scolaire` from ((`eleves` `e` left join `classes` `c` on((`e`.`classe_id` = `c`.`id`))) left join `moyennes_finales` `mf` on((`e`.`id` = `mf`.`eleve_id`))) where (`e`.`status` = 'actif') order by `c`.`nom`,`mf`.`moyenne_finale` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_stats_classes`
--

/*!50001 DROP VIEW IF EXISTS `v_stats_classes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_stats_classes` AS select `c`.`id` AS `id`,`c`.`nom` AS `nom`,`c`.`niveau` AS `niveau`,`c`.`capacite` AS `capacite`,count(`e`.`id`) AS `total_eleves`,(`c`.`capacite` - count(`e`.`id`)) AS `places_restantes` from (`classes` `c` left join `eleves` `e` on(((`c`.`id` = `e`.`classe_id`) and (`e`.`status` = 'actif')))) group by `c`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-07 14:42:14
